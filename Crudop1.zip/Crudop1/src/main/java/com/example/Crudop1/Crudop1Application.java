package com.example.Crudop1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Crudop1Application {

	public static void main(String[] args) {
		SpringApplication.run(Crudop1Application.class, args);
	}

}
